# Cortisol Mod (Fabric, Minecraft 1.21.11, client-side)

Watches your chat for "X paid you $amount" lines on DonutSMP and reacts.

## Behavior
- Payment >= 100K: rolls a 1 in 137,000 chance for the Pirate Token.
- Pirate Token: gold alert, winner is pinned to #1 on the leaderboard for 30 minutes.
- Single payment >= 10M: "crazy" alert (red flash, shaking text, thunder).
- Single payment >= 1B: "insane" alert (rainbow text, camera shake, wither + dragon sounds).
- Total received (or one payment) >= 10B: full-screen END STREAM. Stays until `/cortisol dismiss`.
- Every 10 minutes: top 5 donator leaderboard shows for 20 seconds.

## Build
Needs Java 21 and Gradle (network access for the first build).

    gradle wrapper
    ./gradlew build

The jar is in `build/libs/cortisol-mod-1.0.0.jar`. Put it in `.minecraft/mods` with Fabric API for 1.21.11.

## Commands
- `/cortisol test 150k [name]` simulate a payment (also: 12m, 2b, 10b)
- `/cortisol token <name>` force a Pirate Token pull
- `/cortisol board` show the leaderboard now
- `/cortisol dismiss` clear the END STREAM screen
- `/cortisol reset` wipe totals
- `/cortisol reload` reload `config/cortisol.json`
- `/cortisol status` show running total

## Config
`.minecraft/config/cortisol.json` holds thresholds, odds, timers, sounds, camera shake and `payRegex`.
If DonutSMP words the pay message differently, edit `payRegex` (group 1 = name, 2 = number, 3 = K/M/B/T suffix), then `/cortisol reload`.
