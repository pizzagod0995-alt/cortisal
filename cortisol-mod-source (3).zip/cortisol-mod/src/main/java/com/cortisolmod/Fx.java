package com.cortisolmod;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Random;

/**
 * Screen effects + payment dings. Every payment gets a ding and a toast;
 * the bigger the payment, the bigger the scene (tier 0..4).
 *   tier 0: any payment            ding + toast
 *   tier 1: >= coinShowerMin       coin shower
 *   tier 2: >= fireworksMin        fireworks + big counter
 *   tier 3: >= crazyMin            confetti cannons, shockwaves, lightning
 *   tier 4: >= insaneMin           full meltdown (glitch, embers, storm)
 */
public final class Fx {
	private Fx() {}

	private enum Type { COIN, CONFETTI, EMBER, BOLT, RING, FIREWORK }

	private static final class P { float x, y, vx, vy, grav, drag, life, max; int size, rgb; }
	private static final class Ring { float age, max, maxR; int rgb; }
	private static final class Bolt { float x; long until, seed; int rgb; }
	private static final class Emitter { Type type; float rate, acc; long until; }
	private static final class Toast { String name; long amount; int tier; long start; }
	private static final class Task { long at; Runnable run; }

	private static final long FOREVER = Long.MAX_VALUE / 4;
	private static final Random R = new Random();

	private static final List<P> parts = new ArrayList<>();
	private static final List<Ring> rings = new ArrayList<>();
	private static final List<Bolt> bolts = new ArrayList<>();
	private static final List<Emitter> emitters = new ArrayList<>();
	private static final List<Toast> toasts = new ArrayList<>();
	private static final List<Task> tasks = new ArrayList<>();

	private static int W = 480, H = 270;
	private static long lastNanos = 0;

	private static long flashStart, flashDur;
	private static int flashRgb;
	private static float flashMax;
	private static long glitchUntil, shakeUntil, borderUntil;
	private static int borderTier;
	private static String popName;
	private static long popAmount, popStart, popDur;
	private static int popTier;

	// ------------------------------------------------------------------ helpers

	private static float rnd(float a, float b) { return a + R.nextFloat() * (b - a); }

	private static int argb(float alpha, int rgb) {
		int a = (int) (Math.max(0f, Math.min(1f, alpha)) * 255f);
		return (a << 24) | (rgb & 0xFFFFFF);
	}

	private static int hsb(float h) {
		return java.awt.Color.HSBtoRGB(h - (float) Math.floor(h), 0.85f, 1f) & 0xFFFFFF;
	}

	private static int rainbow(long now, float speed) {
		return hsb((now * speed) / 1000f);
	}

	private static void play(SoundEvent ev, float pitch, float vol) {
		if (!CortisolMod.config.sounds) return;
		Minecraft.getInstance().getSoundManager().play(SimpleSoundInstance.forUI(ev, pitch, vol * CortisolMod.config.dingVolume));
	}

	private static void later(long delayMs, Runnable r) {
		Task t = new Task();
		t.at = System.currentTimeMillis() + delayMs;
		t.run = r;
		tasks.add(t);
	}

	private static void emit(Type type, float rate, long durMs) {
		Emitter e = new Emitter();
		e.type = type;
		e.rate = rate;
		e.until = durMs >= FOREVER ? FOREVER : System.currentTimeMillis() + durMs;
		emitters.add(e);
	}

	private static void flash(int rgb, float max, long durMs) {
		flashStart = System.currentTimeMillis();
		flashDur = durMs;
		flashRgb = rgb;
		flashMax = max;
	}

	private static void add(P p) {
		if (parts.size() < 2500) parts.add(p);
	}

	public static int tier(long amount) {
		Config c = CortisolMod.config;
		if (amount >= c.insaneMin) return 4;
		if (amount >= c.crazyMin) return 3;
		if (amount >= c.fireworksMin) return 2;
		if (amount >= c.coinShowerMin) return 1;
		return 0;
	}

	// ------------------------------------------------------------------ spawners

	private static void coin() {
		P p = new P();
		p.x = rnd(0, W);
		p.y = -6;
		p.vx = rnd(-25, 25);
		p.vy = rnd(60, 160);
		p.grav = rnd(120, 220);
		p.life = p.max = rnd(3.5f, 6f);
		p.size = R.nextBoolean() ? 3 : 4;
		p.rgb = R.nextInt(4) == 0 ? 0xFFF2A0 : 0xFFD700;
		add(p);
	}

	private static void confetti() {
		P p = new P();
		p.x = rnd(0, W);
		p.y = -6;
		p.vx = rnd(-60, 60);
		p.vy = rnd(50, 140);
		p.grav = 25;
		p.drag = 0.4f;
		p.life = p.max = rnd(4f, 7f);
		p.size = 3;
		p.rgb = hsb(R.nextFloat());
		add(p);
	}

	private static void ember() {
		P p = new P();
		p.x = rnd(0, W);
		p.y = H + 4;
		p.vx = rnd(-18, 18);
		p.vy = -rnd(40, 150);
		p.grav = -4;
		p.life = p.max = rnd(2f, 4f);
		p.size = 2;
		int[] cols = {0xFF5A1E, 0xFF9A2E, 0xFFD23E};
		p.rgb = cols[R.nextInt(cols.length)];
		add(p);
	}

	private static void cannon(int side) {
		for (int i = 0; i < 28; i++) {
			P p = new P();
			p.x = side == 0 ? 0 : W;
			p.y = H;
			p.vx = (side == 0 ? 1 : -1) * rnd(80, 320);
			p.vy = -rnd(200, 480);
			p.grav = 260;
			p.drag = 0.3f;
			p.life = p.max = rnd(3f, 4.5f);
			p.size = 3;
			p.rgb = hsb(R.nextFloat());
			add(p);
		}
	}

	private static void burst(float cx, float cy, int rgb, int count) {
		for (int i = 0; i < count; i++) {
			double ang = R.nextDouble() * Math.PI * 2;
			float sp = rnd(40, 200);
			P p = new P();
			p.x = cx;
			p.y = cy;
			p.vx = (float) Math.cos(ang) * sp;
			p.vy = (float) Math.sin(ang) * sp;
			p.grav = 70;
			p.drag = 0.6f;
			p.life = p.max = rnd(0.8f, 1.6f);
			p.size = 2;
			p.rgb = R.nextInt(5) == 0 ? 0xFFFFFF : rgb;
			add(p);
		}
	}

	private static void ring(int rgb, float maxR, float dur) {
		Ring r = new Ring();
		r.max = dur;
		r.maxR = maxR;
		r.rgb = rgb;
		rings.add(r);
	}

	private static void bolt() {
		Bolt b = new Bolt();
		b.x = rnd(W * 0.05f, W * 0.95f);
		b.until = System.currentTimeMillis() + 220;
		b.seed = R.nextLong();
		b.rgb = R.nextBoolean() ? 0xBFD8FF : 0xFFFFFF;
		bolts.add(b);
		if (R.nextInt(3) == 0) flash(0xFFFFFF, 0.35f, 120);
		if (R.nextInt(2) == 0) play(SoundEvents.LIGHTNING_BOLT_THUNDER, rnd(0.7f, 1.2f), 0.5f);
	}

	private static void firework() {
		float cx = rnd(W * 0.15f, W * 0.85f);
		float cy = rnd(H * 0.12f, H * 0.5f);
		int rgb = hsb(R.nextFloat());
		play(SoundEvents.FIREWORK_ROCKET_LAUNCH, rnd(0.9f, 1.1f), 0.6f);
		later(450, () -> {
			burst(cx, cy, rgb, 70);
			burst(cx, cy, hsb(R.nextFloat()), 35);
			play(SoundEvents.FIREWORK_ROCKET_BLAST, rnd(0.9f, 1.1f), 0.8f);
			play(SoundEvents.FIREWORK_ROCKET_TWINKLE, 1.0f, 0.6f);
		});
	}

	private static void spawn(Type t) {
		switch (t) {
			case COIN -> coin();
			case CONFETTI -> confetti();
			case EMBER -> ember();
			case BOLT -> bolt();
			case RING -> ring(R.nextBoolean() ? 0xFF3030 : 0xFFD700, W * 0.75f, 1.1f);
			case FIREWORK -> firework();
		}
	}

	// ------------------------------------------------------------------ public triggers

	public static void payment(String name, long amount) {
		int t = tier(amount);
		Toast ts = new Toast();
		ts.name = name;
		ts.amount = amount;
		ts.tier = t;
		ts.start = System.currentTimeMillis();
		toasts.add(0, ts);
		while (toasts.size() > 4) toasts.remove(toasts.size() - 1);

		ding(t);
		burst(70, 40, t >= 1 ? 0xFFD700 : 0x66FF66, 10 + t * 8);

		switch (t) {
			case 1 -> {
				emit(Type.COIN, 14, 2500);
				border(1, 2500);
			}
			case 2 -> {
				popup(name, amount, 2, 3500);
				emit(Type.COIN, 45, 4000);
				emit(Type.FIREWORK, 2.2f, 3500);
				flash(0xFFD700, 0.25f, 350);
				border(2, 4000);
			}
			case 3 -> {
				popup(name, amount, 3, 6000);
				emit(Type.CONFETTI, 70, 6000);
				emit(Type.BOLT, 1.6f, 3500);
				emit(Type.FIREWORK, 3, 4000);
				emit(Type.RING, 1.6f, 2500);
				later(0, () -> cannon(0));
				later(0, () -> cannon(1));
				later(500, () -> { cannon(0); cannon(1); });
				later(1000, () -> { cannon(0); cannon(1); });
				flash(0xFFFFFF, 0.6f, 180);
				glitchUntil = System.currentTimeMillis() + 900;
				shakeUntil = System.currentTimeMillis() + 2500;
				border(3, 6000);
			}
			case 4 -> {
				popup(name, amount, 4, 12000);
				emit(Type.COIN, 80, 8000);
				emit(Type.CONFETTI, 90, 10000);
				emit(Type.EMBER, 90, 12000);
				emit(Type.BOLT, 3.5f, 12000);
				emit(Type.RING, 1.4f, 12000);
				emit(Type.FIREWORK, 4, 10000);
				for (int i = 0; i < 6; i++) {
					final int k = i;
					later(i * 1500L, () -> { cannon(0); cannon(1); if (k % 2 == 0) flash(0xFF0000, 0.5f, 300); });
				}
				flash(0xFFFFFF, 0.8f, 250);
				long now = System.currentTimeMillis();
				glitchUntil = now + 12000;
				shakeUntil = now + 12000;
				border(4, 12000);
			}
			default -> { }
		}
	}

	/** Pirate Token pulled. */
	public static void token(String name) {
		play(SoundEvents.UI_TOAST_CHALLENGE_COMPLETE, 1.0f, 1.0f);
		play(SoundEvents.PLAYER_LEVELUP, 0.8f, 1.0f);
		emit(Type.CONFETTI, 60, 6000);
		emit(Type.FIREWORK, 3, 6000);
		emit(Type.RING, 1.2f, 3000);
		later(0, () -> { cannon(0); cannon(1); });
		later(700, () -> { cannon(0); cannon(1); });
		flash(0xFFD700, 0.6f, 400);
		border(1, 8000);
	}

	/** END STREAM: everything, forever, until dismissed. */
	public static void end() {
		clear();
		emit(Type.COIN, 60, FOREVER);
		emit(Type.CONFETTI, 80, FOREVER);
		emit(Type.EMBER, 80, FOREVER);
		emit(Type.BOLT, 4, FOREVER);
		emit(Type.RING, 1.2f, FOREVER);
		emit(Type.FIREWORK, 5, FOREVER);
		glitchUntil = FOREVER;
		shakeUntil = FOREVER;
		border(4, FOREVER);
		flash(0xFFFFFF, 1.0f, 400);
	}

	public static void clear() {
		parts.clear();
		rings.clear();
		bolts.clear();
		emitters.clear();
		toasts.clear();
		tasks.clear();
		glitchUntil = 0;
		shakeUntil = 0;
		borderUntil = 0;
		flashDur = 0;
		popName = null;
	}

	public static boolean shaking() {
		return System.currentTimeMillis() < shakeUntil;
	}

	private static void border(int tier, long durMs) {
		borderTier = tier;
		borderUntil = durMs >= FOREVER ? FOREVER : System.currentTimeMillis() + durMs;
	}

	private static void popup(String name, long amount, int tier, long durMs) {
		popName = name;
		popAmount = amount;
		popTier = tier;
		popStart = System.currentTimeMillis();
		popDur = durMs;
	}

	private static void ding(int t) {
		play(SoundEvents.EXPERIENCE_ORB_PICKUP, t == 0 ? 1.4f : 1.0f, 0.9f);
		if (t >= 1) {
			later(80, () -> play(SoundEvents.EXPERIENCE_ORB_PICKUP, 1.26f, 0.9f));
			later(160, () -> play(SoundEvents.EXPERIENCE_ORB_PICKUP, 1.5f, 0.9f));
		}
		if (t >= 2) {
			later(240, () -> play(SoundEvents.EXPERIENCE_ORB_PICKUP, 2.0f, 1.0f));
			play(SoundEvents.BELL_BLOCK, 1.2f, 1.0f);
			later(280, () -> play(SoundEvents.UI_TOAST_CHALLENGE_COMPLETE, 1.0f, 0.8f));
		}
		if (t >= 3) {
			play(SoundEvents.LIGHTNING_BOLT_THUNDER, 1.0f, 1.0f);
		}
	}

	// ------------------------------------------------------------------ update

	/** Client tick: run scheduled sounds / bursts. */
	public static void tick() {
		if (tasks.isEmpty()) return;
		long now = System.currentTimeMillis();
		List<Task> due = new ArrayList<>();
		Iterator<Task> it = tasks.iterator();
		while (it.hasNext()) {
			Task t = it.next();
			if (now >= t.at) {
				due.add(t);
				it.remove();
			}
		}
		for (Task t : due) t.run.run();
	}

	private static void update(float dt, long now) {
		Iterator<Emitter> ei = emitters.iterator();
		List<Type> toSpawn = new ArrayList<>();
		while (ei.hasNext()) {
			Emitter e = ei.next();
			if (now >= e.until) {
				ei.remove();
				continue;
			}
			e.acc += e.rate * dt;
			while (e.acc >= 1f) {
				e.acc -= 1f;
				toSpawn.add(e.type);
			}
		}
		for (Type t : toSpawn) spawn(t);

		Iterator<P> pi = parts.iterator();
		while (pi.hasNext()) {
			P p = pi.next();
			p.life -= dt;
			if (p.life <= 0) {
				pi.remove();
				continue;
			}
			p.vx *= Math.max(0f, 1f - p.drag * dt);
			p.vy += p.grav * dt;
			p.x += p.vx * dt;
			p.y += p.vy * dt;
			if (p.y > H + 12 || p.y < -40 || p.x < -40 || p.x > W + 40) pi.remove();
		}

		Iterator<Ring> ri = rings.iterator();
		while (ri.hasNext()) {
			Ring r = ri.next();
			r.age += dt;
			if (r.age >= r.max) ri.remove();
		}

		Iterator<Bolt> bi = bolts.iterator();
		while (bi.hasNext()) {
			if (now > bi.next().until) bi.remove();
		}

		Iterator<Toast> ti = toasts.iterator();
		while (ti.hasNext()) {
			Toast t = ti.next();
			if (now - t.start > toastDur(t.tier)) ti.remove();
		}

		if (popName != null && now - popStart > popDur) popName = null;
	}

	private static long toastDur(int tier) {
		return 3500 + tier * 900L;
	}

	// ------------------------------------------------------------------ render

	public static void render(GuiGraphics g, Font font, int w, int h) {
		W = w;
		H = h;
		long nanos = System.nanoTime();
		float dt = lastNanos == 0 ? 0.016f : Math.min(0.05f, (nanos - lastNanos) / 1_000_000_000f);
		lastNanos = nanos;
		long now = System.currentTimeMillis();
		update(dt, now);

		boolean idle = parts.isEmpty() && rings.isEmpty() && bolts.isEmpty() && toasts.isEmpty()
				&& popName == null && now >= glitchUntil && now >= borderUntil && now >= flashStart + flashDur;
		if (idle) return;

		drawFlash(g, now);
		drawRings(g);
		drawBolts(g, now);
		drawParticles(g);
		drawGlitch(g, now);
		drawBorder(g, now);
		drawToasts(g, font, now);
		drawPopup(g, font, now);
	}

	private static void drawFlash(GuiGraphics g, long now) {
		if (now >= flashStart + flashDur) return;
		float a = flashMax * (1f - (now - flashStart) / (float) flashDur);
		g.fill(0, 0, W, H, argb(a, flashRgb));
	}

	private static void drawRings(GuiGraphics g) {
		for (Ring r : rings) {
			float p = r.age / r.max;
			float eased = 1f - (1f - p) * (1f - p);
			float rad = r.maxR * eased;
			float alpha = 1f - p;
			int n = Math.max(48, (int) (rad * 0.9f));
			int col = argb(alpha, r.rgb);
			for (int i = 0; i < n; i++) {
				double ang = i * Math.PI * 2 / n;
				int px = (int) (W / 2f + Math.cos(ang) * rad);
				int py = (int) (H / 2f + Math.sin(ang) * rad * 0.62);
				g.fill(px, py, px + 3, py + 3, col);
			}
		}
	}

	private static void drawBolts(GuiGraphics g, long now) {
		for (Bolt b : bolts) {
			Random rr = new Random(b.seed + now / 60);
			float cx = b.x;
			float life = Math.max(0f, (b.until - now) / 220f);
			for (int y = 0; y < H; y += 12) {
				float nx = cx + rr.nextInt(23) - 11;
				int x0 = (int) Math.min(cx, nx);
				int x1 = (int) Math.max(cx, nx);
				g.fill(x0 - 4, y, x1 + 5, y + 13, argb(0.18f * life + 0.05f, 0x6FA8FF));
				g.fill(x0 - 1, y, x1 + 2, y + 13, argb(0.5f + 0.5f * life, b.rgb));
				cx = nx;
			}
		}
	}

	private static void drawParticles(GuiGraphics g) {
		for (P p : parts) {
			float a = Math.min(1f, p.life / (p.max * 0.35f));
			int x = (int) p.x;
			int y = (int) p.y;
			g.fill(x, y, x + p.size, y + p.size, argb(a, p.rgb));
		}
	}

	private static void drawGlitch(GuiGraphics g, long now) {
		if (now >= glitchUntil) return;
		int[] cols = {0x00FFFF, 0xFF00FF, 0xFF2020, 0xFFFFFF};
		int bars = 5 + R.nextInt(6);
		for (int i = 0; i < bars; i++) {
			int y = R.nextInt(Math.max(1, H));
			int hh = 2 + R.nextInt(13);
			int x0 = R.nextInt(Math.max(1, W / 3));
			int x1 = W - R.nextInt(Math.max(1, W / 3));
			g.fill(x0, y, x1, y + hh, argb(0.16f + R.nextFloat() * 0.2f, cols[R.nextInt(cols.length)]));
		}
		for (int y = 0; y < H; y += 5) {
			g.fill(0, y, W, y + 1, argb(0.12f, 0x000000));
		}
	}

	private static void drawBorder(GuiGraphics g, long now) {
		if (now >= borderUntil) return;
		float pulse = 0.5f + 0.5f * (float) Math.sin(now / 90.0);
		int rgb = switch (borderTier) {
			case 1 -> 0xFFD700;
			case 2 -> 0xFF9A2E;
			case 3 -> 0xFF2020;
			default -> rainbow(now, 1.2f);
		};
		float fade = Math.min(1f, (borderUntil - now) / 500f);
		int c = argb((0.35f + 0.4f * pulse) * fade, rgb);
		int t = 2 + borderTier * 2;
		g.fill(0, 0, W, t, c);
		g.fill(0, H - t, W, H, c);
		g.fill(0, t, t, H - t, c);
		g.fill(W - t, t, W, H - t, c);
	}

	private static int tierColor(int tier, long now) {
		return switch (tier) {
			case 0 -> 0xFF66FF66;
			case 1 -> 0xFFFFD700;
			case 2 -> 0xFFFF9A2E;
			case 3 -> 0xFFFF3030;
			default -> 0xFF000000 | rainbow(now, 1.5f);
		};
	}

	private static void drawToasts(GuiGraphics g, Font font, long now) {
		int pw = 168;
		for (int i = 0; i < toasts.size(); i++) {
			Toast t = toasts.get(i);
			long age = now - t.start;
			long dur = toastDur(t.tier);
			float in = Math.min(1f, age / 250f);
			float out = Math.min(1f, (dur - age) / 300f);
			float slide = (1f - (1f - in) * (1f - in)) * Math.max(0f, out);
			int x = (int) (-pw + (pw + 8) * slide);
			int y = 8 + i * 36;
			int accent = tierColor(t.tier, now);
			g.fill(x, y, x + pw, y + 32, 0xCC000000);
			g.fill(x, y, x + 3, y + 32, accent);
			g.drawString(font, t.name + " paid you", x + 8, y + 5, 0xFFFFFFFF, true);
			g.pose().pushMatrix();
			g.pose().translate(x + 8, y + 16);
			g.pose().scale(1.5f, 1.5f);
			g.drawString(font, "+$" + Amounts.format(t.amount), 0, 0, accent, true);
			g.pose().popMatrix();
		}
	}

	private static void drawPopup(GuiGraphics g, Font font, long now) {
		if (popName == null) return;
		float t = (now - popStart) / 1000f;
		float p = Math.min(1f, t / 0.9f);
		float ease = 1f - (1f - p) * (1f - p) * (1f - p);
		long shown = (long) (popAmount * ease);
		String text = "+$" + Amounts.format(shown);

		float base = switch (popTier) {
			case 2 -> 3.5f;
			case 3 -> 5f;
			default -> 6f;
		};
		float scale = base * (1f + 0.25f * Math.max(0f, 1f - t * 4f));
		scale = Math.min(scale, (W * 0.9f) / Math.max(1, font.width(text)));

		float jx = 0, jy = 0;
		if (popTier >= 3) {
			jx = (R.nextFloat() - 0.5f) * 2f * popTier;
			jy = (R.nextFloat() - 0.5f) * 2f * popTier;
		}
		int color = popTier >= 4 ? (0xFF000000 | rainbow(now, 1.6f))
				: popTier == 3 ? ((Math.sin(now / 80.0) > 0) ? 0xFFFF3030 : 0xFFFFA030)
				: 0xFFFFD700;

		float cy = H * 0.68f;
		g.pose().pushMatrix();
		g.pose().translate(W / 2f + jx + 1, cy + jy + 1);
		g.pose().scale(scale, scale);
		g.drawCenteredString(font, text, 0, -font.lineHeight / 2, 0xFF000000);
		g.pose().popMatrix();
		g.pose().pushMatrix();
		g.pose().translate(W / 2f + jx, cy + jy);
		g.pose().scale(scale, scale);
		g.drawCenteredString(font, text, 0, -font.lineHeight / 2, color);
		g.pose().popMatrix();

		g.pose().pushMatrix();
		g.pose().translate(W / 2f, cy + font.lineHeight * scale / 2f + 8);
		g.pose().scale(1.5f, 1.5f);
		g.drawCenteredString(font, "from " + popName, 0, 0, 0xFFFFFFFF);
		g.pose().popMatrix();
	}
}
