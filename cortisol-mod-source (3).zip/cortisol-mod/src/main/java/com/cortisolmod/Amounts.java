package com.cortisolmod;

import java.util.Locale;

public final class Amounts {
	private Amounts() {}

	/** Parses "100000", "100,000", "1.5M", "2b", "$250k". Returns -1 if it can't be read. */
	public static long parse(String raw) {
		if (raw == null) return -1;
		String s = raw.trim().toLowerCase(Locale.ROOT).replace("$", "").replace(",", "");
		long mult = 1;
		if (!s.isEmpty()) {
			char last = s.charAt(s.length() - 1);
			switch (last) {
				case 'k' -> mult = 1_000L;
				case 'm' -> mult = 1_000_000L;
				case 'b' -> mult = 1_000_000_000L;
				case 't' -> mult = 1_000_000_000_000L;
				default -> { }
			}
			if (mult != 1) s = s.substring(0, s.length() - 1);
		}
		try {
			return Math.round(Double.parseDouble(s) * mult);
		} catch (NumberFormatException e) {
			return -1;
		}
	}

	public static String format(long v) {
		if (v >= 1_000_000_000_000L) return trim(v / 1_000_000_000_000.0) + "T";
		if (v >= 1_000_000_000L) return trim(v / 1_000_000_000.0) + "B";
		if (v >= 1_000_000L) return trim(v / 1_000_000.0) + "M";
		if (v >= 1_000L) return trim(v / 1_000.0) + "K";
		return Long.toString(v);
	}

	private static String trim(double d) {
		String s = String.format(Locale.ROOT, "%.2f", d);
		if (s.contains(".")) s = s.replaceAll("0+$", "").replaceAll("\\.$", "");
		return s;
	}
}
