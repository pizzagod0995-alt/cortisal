package com.cortisolmod;

import java.text.Normalizer;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Turns messy server chat (small-caps fonts, color codes, odd spacing) into something the pay pattern can match. */
public final class ChatParse {
	private ChatParse() {}

	public record Result(String name, long amount) {}

	// small-caps letters a..z (x has no small-cap form, so it stays plain)
	private static final String SMALL_CAPS =
			"ᴀʙᴄᴅᴇꜰɢʜɪᴊᴋʟᴍ"
					+ "ɴᴏᴘǫʀꜱᴛᴜᴠᴡxʏᴢ";

	public static String normalize(String s) {
		if (s == null) return "";
		s = s.replaceAll("§.", "");
		s = Normalizer.normalize(s, Normalizer.Form.NFKC);
		StringBuilder sb = new StringBuilder(s.length());
		for (int i = 0; i < s.length(); i++) {
			char ch = s.charAt(i);
			if (ch == '​' || ch == '‌' || ch == '‍' || ch == '﻿' || ch == '­') continue;
			if (ch == ' ') { sb.append(' '); continue; }
			int idx = SMALL_CAPS.indexOf(ch);
			if (idx >= 0) sb.append((char) ('a' + idx));
			else sb.append(ch);
		}
		return sb.toString();
	}

	/** Returns null if the line isn't a payment to you. */
	public static Result parse(String raw, Pattern pattern) {
		String text = normalize(raw);
		Matcher m = pattern.matcher(text);
		if (!m.find()) return null;
		String name = m.group(1);
		String suffix = m.groupCount() >= 3 && m.group(3) != null ? m.group(3) : "";
		long amount = Amounts.parse(m.group(2) + suffix);
		if (amount <= 0) return null;
		return new Result(name, amount);
	}
}
