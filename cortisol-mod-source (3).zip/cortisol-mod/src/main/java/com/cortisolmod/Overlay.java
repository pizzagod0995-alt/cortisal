package com.cortisolmod;

import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;

import java.awt.Color;
import java.util.ArrayDeque;
import java.util.List;
import java.util.Map;
import java.util.Queue;
import java.util.concurrent.ThreadLocalRandom;

/** Draws the alerts and the leaderboard, and owns the alert queue. */
public final class Overlay {
	private Overlay() {}

	public enum Kind { CRAZY, INSANE, TOKEN, END }

	public static final class Alert {
		final Kind kind;
		final String title;
		final String sub;
		long start;
		final long duration; // ms, ignored for END (stays until dismissed)
		long lastSound;

		Alert(Kind kind, String title, String sub, long duration) {
			this.kind = kind;
			this.title = title;
			this.sub = sub;
			this.duration = duration;
		}

		boolean expired(long now) {
			return kind != Kind.END && now - start > duration;
		}
	}

	private static final Queue<Alert> queue = new ArrayDeque<>();
	private static Alert current = null;

	private static long boardUntil = 0;

	public static void push(Kind kind, String title, String sub) {
		long dur = switch (kind) {
			case CRAZY -> 6_000;
			case INSANE -> 12_000;
			case TOKEN -> 10_000;
			case END -> 0;
		};
		Alert a = new Alert(kind, title, sub, dur);
		if (kind == Kind.END) {
			queue.clear();
			start(a);
		} else if (current == null || current.expired(System.currentTimeMillis())) {
			start(a);
		} else {
			queue.add(a);
		}
	}

	public static void dismiss() {
		queue.clear();
		current = null;
		Fx.clear();
	}

	public static void showBoard(int seconds) {
		boardUntil = System.currentTimeMillis() + seconds * 1000L;
	}

	public static boolean cameraShaking() {
		if (Fx.shaking()) return true;
		return current != null && (current.kind == Kind.INSANE || current.kind == Kind.END)
				&& !current.expired(System.currentTimeMillis());
	}

	private static void start(Alert a) {
		a.start = System.currentTimeMillis();
		a.lastSound = 0;
		current = a;
		if (!CortisolMod.config.sounds) return;
		switch (a.kind) {
			case CRAZY -> play(SoundEvents.LIGHTNING_BOLT_THUNDER, 1.0f, 1.0f);
			case INSANE -> {
				play(SoundEvents.WITHER_SPAWN, 1.0f, 1.0f);
				play(SoundEvents.ENDER_DRAGON_GROWL, 0.8f, 1.0f);
			}
			case TOKEN -> {
				play(SoundEvents.UI_TOAST_CHALLENGE_COMPLETE, 1.0f, 1.0f);
				play(SoundEvents.PLAYER_LEVELUP, 0.7f, 1.0f);
			}
			case END -> play(SoundEvents.WITHER_DEATH, 0.7f, 1.0f);
		}
	}

	private static void play(SoundEvent ev, float pitch, float vol) {
		Minecraft.getInstance().getSoundManager().play(SimpleSoundInstance.forUI(ev, pitch, vol));
	}

	/** Called every client tick. */
	public static void tick() {
		Fx.tick();
		long now = System.currentTimeMillis();
		if (current != null && current.expired(now)) {
			current = queue.poll();
			if (current != null) start(current);
		}
		// repeating sounds for the loud alerts
		if (current != null && CortisolMod.config.sounds && now - current.lastSound > 1800) {
			if (current.kind == Kind.END) {
				play(SoundEvents.LIGHTNING_BOLT_THUNDER, 0.6f, 1.0f);
				current.lastSound = now;
			} else if (current.kind == Kind.INSANE) {
				play(SoundEvents.LIGHTNING_BOLT_THUNDER, 0.8f, 1.0f);
				current.lastSound = now;
			}
		}
	}

	public static void render(GuiGraphics g, DeltaTracker dt) {
		Minecraft mc = Minecraft.getInstance();
		if (mc.options.hideGui && current == null) return;
		long now = System.currentTimeMillis();
		int w = g.guiWidth();
		int h = g.guiHeight();
		Font font = mc.font;

		Fx.render(g, font, w, h);

		if (current != null && !current.expired(now)) {
			renderAlert(g, font, current, now, w, h);
		}
		if (now < boardUntil) {
			renderBoard(g, font, w, h);
		}
	}

	private static void renderAlert(GuiGraphics g, Font font, Alert a, long now, int w, int h) {
		double t = (now - a.start) / 1000.0;
		ThreadLocalRandom r = ThreadLocalRandom.current();

		// background flash
		int flashColor;
		double speed;
		int maxAlpha;
		switch (a.kind) {
			case CRAZY -> { flashColor = 0xFF2020; speed = 8; maxAlpha = 90; }
			case INSANE -> { flashColor = 0xFF0000; speed = 16; maxAlpha = 150; }
			case TOKEN -> { flashColor = 0xFFC800; speed = 6; maxAlpha = 100; }
			default -> { flashColor = 0x000000; speed = 12; maxAlpha = 230; }
		}
		int alpha = (int) (Math.abs(Math.sin(t * speed)) * maxAlpha);
		if (a.kind == Kind.END) alpha = Math.max(alpha, 150);
		g.fill(0, 0, w, h, (alpha << 24) | flashColor);
		if (a.kind == Kind.END) {
			int redA = (int) (Math.abs(Math.sin(t * 6)) * 120);
			g.fill(0, 0, w, h, (redA << 24) | 0xFF0000);
		}

		// title
		float scale = switch (a.kind) {
			case CRAZY -> 3.0f;
			case INSANE -> 4.0f;
			case TOKEN -> 4.0f;
			case END -> 6.0f;
		};
		// shrink if the title wouldn't fit
		float maxScale = (w * 0.92f) / Math.max(1, font.width(a.title));
		scale = Math.min(scale, maxScale);

		float shake = switch (a.kind) {
			case CRAZY -> 3f;
			case INSANE -> 8f;
			case TOKEN -> 2f;
			case END -> 12f;
		};
		float dx = (float) ((r.nextDouble() - 0.5) * 2 * shake);
		float dy = (float) ((r.nextDouble() - 0.5) * 2 * shake);

		int color;
		if (a.kind == Kind.INSANE || a.kind == Kind.END) {
			color = Color.HSBtoRGB((float) ((t * 1.5) % 1.0), 1f, 1f) | 0xFF000000;
		} else if (a.kind == Kind.TOKEN) {
			color = (Math.sin(t * 10) > 0) ? 0xFFFFD700 : 0xFFFFFFFF;
		} else {
			color = (Math.sin(t * 12) > 0) ? 0xFFFF3030 : 0xFFFFA030;
		}

		g.pose().pushMatrix();
		g.pose().translate(w / 2f + dx, h * 0.38f + dy);
		g.pose().scale(scale, scale);
		g.drawCenteredString(font, a.title, 0, -font.lineHeight / 2, color);
		g.pose().popMatrix();

		// subtitle
		g.pose().pushMatrix();
		g.pose().translate(w / 2f + dx * 0.5f, h * 0.38f + font.lineHeight * scale + 6 + dy * 0.5f);
		float subScale = Math.min(2.0f, (w * 0.9f) / Math.max(1, font.width(a.sub)));
		g.pose().scale(subScale, subScale);
		g.drawCenteredString(font, a.sub, 0, 0, 0xFFFFFFFF);
		g.pose().popMatrix();

		if (a.kind == Kind.END) {
			g.drawCenteredString(font, "(type /cortisol dismiss to clear)", w / 2, h - 24, 0xFFAAAAAA);
		}
	}

	private static void renderBoard(GuiGraphics g, Font font, int w, int h) {
		List<Map.Entry<String, Long>> top = CortisolMod.state.top(5);
		int rows = Math.max(1, top.size());
		int panelW = 190;
		int panelH = 22 + rows * 12 + 6;
		int x = w - panelW - 8;
		int y = 8;
		g.fill(x, y, x + panelW, y + panelH, 0xC0000000);
		g.fill(x, y, x + panelW, y + 1, 0xFFFFD700);
		g.drawString(font, "TOP DONATORS", x + 6, y + 6, 0xFFFFD700, true);

		if (top.isEmpty()) {
			g.drawString(font, "nobody paid yet :(", x + 6, y + 22, 0xFFAAAAAA, true);
			return;
		}
		boolean pinned = CortisolMod.state.pinActive();
		for (int i = 0; i < top.size(); i++) {
			Map.Entry<String, Long> e = top.get(i);
			String left = (i + 1) + ". " + e.getKey() + (i == 0 && pinned ? " [PIRATE]" : "");
			String right = "$" + Amounts.format(e.getValue());
			int rowY = y + 22 + i * 12;
			int col = (i == 0 && pinned) ? 0xFFFFD700 : 0xFFFFFFFF;
			g.drawString(font, left, x + 6, rowY, col, true);
			g.drawString(font, right, x + panelW - 6 - font.width(right), rowY, 0xFF55FF55, true);
		}
	}
}
