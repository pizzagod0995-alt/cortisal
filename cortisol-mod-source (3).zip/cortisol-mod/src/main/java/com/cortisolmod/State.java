package com.cortisolmod;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import net.fabricmc.loader.api.FabricLoader;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;

/** Donation totals + the pinned Pirate Token winner. Saved to config/cortisol_totals.json */
public class State {
	private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

	public final Map<String, Long> totals = new HashMap<>();
	public long grandTotal = 0;
	public boolean endTriggered = false;

	public String pinnedName = null;
	public long pinnedUntil = 0;

	static Path path() {
		return FabricLoader.getInstance().getConfigDir().resolve("cortisol_totals.json");
	}

	public static State load() {
		State s = new State();
		try {
			Path p = path();
			if (Files.exists(p)) {
				Map<String, Long> m = GSON.fromJson(Files.readString(p), new TypeToken<Map<String, Long>>() {}.getType());
				if (m != null) {
					s.totals.putAll(m);
					for (long v : m.values()) s.grandTotal += v;
				}
			}
		} catch (Exception e) {
			CortisolMod.LOG.warn("Could not read totals", e);
		}
		return s;
	}

	public void save() {
		try {
			Files.writeString(path(), GSON.toJson(totals));
		} catch (Exception e) {
			CortisolMod.LOG.warn("Could not save totals", e);
		}
	}

	public void add(String name, long amount) {
		totals.merge(name, amount, Long::sum);
		grandTotal += amount;
		save();
	}

	public void reset() {
		totals.clear();
		grandTotal = 0;
		endTriggered = false;
		pinnedName = null;
		pinnedUntil = 0;
		save();
	}

	public boolean pinActive() {
		return pinnedName != null && System.currentTimeMillis() < pinnedUntil;
	}

	public void pin(String name, long millis) {
		pinnedName = name;
		pinnedUntil = System.currentTimeMillis() + millis;
	}

	/** Top N by total donated; an active Pirate Token holder is forced to #1. */
	public List<Map.Entry<String, Long>> top(int n) {
		List<Map.Entry<String, Long>> list = new ArrayList<>(totals.entrySet());
		list.sort((a, b) -> Long.compare(b.getValue(), a.getValue()));
		if (pinActive()) {
			final String pinned = pinnedName;
			Long val = totals.getOrDefault(pinned, 0L);
			list.removeIf(e -> e.getKey().equalsIgnoreCase(pinned));
			list.add(0, new AbstractMap.SimpleEntry<>(pinned, val));
		}
		return list.size() > n ? list.subList(0, n) : list;
	}
}
