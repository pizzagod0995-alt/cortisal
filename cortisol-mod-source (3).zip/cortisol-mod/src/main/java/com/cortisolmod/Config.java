package com.cortisolmod;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

/** Everything tweakable lives in .minecraft/config/cortisol.json */
public class Config {
	/** Payments at or above this get a roll for the Pirate Token. */
	public long tokenMinPayment = 100_000L;
	/** 1 in N chance per qualifying payment. */
	public int tokenOdds = 137_000;
	/** Single payment >= this triggers the "crazy" alert. */
	public long crazyMin = 10_000_000L;
	/** Single payment >= this triggers the "insane" alert. */
	public long insaneMin = 1_000_000_000L;
	/** Total received (or one single payment) >= this triggers END STREAM. */
	public long endStreamTotal = 10_000_000_000L;

	/** Payments >= this get a coin shower. */
	public long coinShowerMin = 100_000L;
	/** Payments >= this get fireworks + the big counter. */
	public long fireworksMin = 1_000_000L;
	/** Volume multiplier for the payment dings. */
	public float dingVolume = 1.0f;

	public int leaderboardEveryMinutes = 10;
	public int leaderboardShowSeconds = 20;
	/** How long a Pirate Token winner is pinned to #1. */
	public int pinMinutes = 30;
	public boolean cameraShake = true;
	public boolean sounds = true;

	/**
	 * Matches the chat line when someone pays you. Group 1 = name, group 2 = number, group 3 = suffix (K/M/B/T).
	 * If DonutSMP words it differently, edit this and use /cortisol test to check.
	 */
	public String payRegex = "(?i)([\\w.*]{2,24})\\s+(?:has\\s+)?paid\\s+you[^\\d\\p{L}]{0,6}([\\d,]+(?:\\.\\d+)?)\\s*([kmbt])?(?![a-z])";

	/** Internal: lets updates replace an outdated saved payRegex. */
	public int configVersion = 0;

	private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

	static Path path() {
		return FabricLoader.getInstance().getConfigDir().resolve("cortisol.json");
	}

	static Config load() {
		Path p = path();
		try {
			if (Files.exists(p)) {
				Config c = GSON.fromJson(Files.readString(p), Config.class);
				if (c != null) {
					if (c.configVersion < 3) {
						c.payRegex = new Config().payRegex;
						c.configVersion = 3;
						c.save();
					}
					return c;
				}
			}
		} catch (Exception e) {
			CortisolMod.LOG.warn("Could not read config, using defaults", e);
		}
		Config c = new Config();
		c.configVersion = 3;
		c.save();
		return c;
	}

	void save() {
		try {
			Files.writeString(path(), GSON.toJson(this));
		} catch (IOException e) {
			CortisolMod.LOG.warn("Could not save config", e);
		}
	}
}
