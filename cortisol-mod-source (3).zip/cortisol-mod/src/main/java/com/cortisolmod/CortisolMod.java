package com.cortisolmod;

import com.mojang.brigadier.arguments.StringArgumentType;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.command.v2.FabricClientCommandSource;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.message.v1.ClientReceiveMessageEvents;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.concurrent.ThreadLocalRandom;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static net.fabricmc.fabric.api.client.command.v2.ClientCommandManager.argument;
import static net.fabricmc.fabric.api.client.command.v2.ClientCommandManager.literal;

public class CortisolMod implements ClientModInitializer {
	public static final Logger LOG = LoggerFactory.getLogger("cortisolmod");

	public static Config config;
	public static State state;
	private static Pattern payPattern;
	private static long nextBoardAt;

	@Override
	public void onInitializeClient() {
		config = Config.load();
		state = State.load();
		compilePattern();
		scheduleNextBoard();

		// payments show up as system messages on most servers; listen to both paths
		ClientReceiveMessageEvents.GAME.register((message, overlay) -> onChat(message.getString()));
		ClientReceiveMessageEvents.CHAT.register((message, signed, sender, params, ts) -> onChat(message.getString()));

		HudRenderCallback.EVENT.register(Overlay::render);

		ClientTickEvents.END_CLIENT_TICK.register(mc -> {
			Overlay.tick();
			long now = System.currentTimeMillis();
			if (now >= nextBoardAt) {
				Overlay.showBoard(config.leaderboardShowSeconds);
				scheduleNextBoard();
			}
			if (config.cameraShake && Overlay.cameraShaking() && mc.player != null) {
				ThreadLocalRandom r = ThreadLocalRandom.current();
				mc.player.setYRot(mc.player.getYRot() + (float) ((r.nextDouble() - 0.5) * 3.0));
				float pitch = mc.player.getXRot() + (float) ((r.nextDouble() - 0.5) * 3.0);
				mc.player.setXRot(Math.max(-90f, Math.min(90f, pitch)));
			}
		});

		ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) -> dispatcher.register(
				literal("cortisol")
						.then(literal("test")
								.then(argument("amount", StringArgumentType.word())
										.executes(c -> test(c.getSource(), StringArgumentType.getString(c, "amount"), "TestPayer"))
										.then(argument("name", StringArgumentType.word())
												.executes(c -> test(c.getSource(),
														StringArgumentType.getString(c, "amount"),
														StringArgumentType.getString(c, "name"))))))
						.then(literal("token")
								.then(argument("name", StringArgumentType.word())
										.executes(c -> {
											givePirateToken(StringArgumentType.getString(c, "name"));
											return 1;
										})))
						.then(literal("board").executes(c -> {
							Overlay.showBoard(config.leaderboardShowSeconds);
							return 1;
						}))
						.then(literal("dismiss").executes(c -> {
							Overlay.dismiss();
							return 1;
						}))
						.then(literal("reset").executes(c -> {
							state.reset();
							Overlay.dismiss();
							c.getSource().sendFeedback(Component.literal("Cortisol: totals reset."));
							return 1;
						}))
						.then(literal("reload").executes(c -> {
							config = Config.load();
							compilePattern();
							scheduleNextBoard();
							c.getSource().sendFeedback(Component.literal("Cortisol: config reloaded."));
							return 1;
						}))
						.then(literal("debug").executes(c -> {
							debug = !debug;
							c.getSource().sendFeedback(Component.literal("Cortisol debug " + (debug ? "ON: payment-looking chat lines will be shown with MATCH / NO MATCH" : "OFF")));
							return 1;
						}))
						.then(literal("status").executes(c -> {
							c.getSource().sendFeedback(Component.literal("Cortisol: total $"
									+ Amounts.format(state.grandTotal) + " across " + state.totals.size() + " payers."));
							return 1;
						}))
		));

		LOG.info("Cortisol Mod loaded");
	}

	private static void compilePattern() {
		try {
			payPattern = Pattern.compile(config.payRegex);
		} catch (Exception e) {
			LOG.error("Bad payRegex in cortisol.json, falling back to default", e);
			payPattern = Pattern.compile(new Config().payRegex);
		}
	}

	private static void scheduleNextBoard() {
		nextBoardAt = System.currentTimeMillis() + config.leaderboardEveryMinutes * 60_000L;
	}

	private static boolean debug = false;
	private static String lastLine = "";
	private static long lastLineAt = 0;

	private static void onChat(String text) {
		long now = System.currentTimeMillis();
		// the same line can arrive through more than one path; ignore the repeat
		if (text.equals(lastLine) && now - lastLineAt < 500) return;
		lastLine = text;
		lastLineAt = now;

		ChatParse.Result r = ChatParse.parse(text, payPattern);
		if (debug) {
			String low = ChatParse.normalize(text).toLowerCase();
			if (low.contains("pay") || low.contains("$") || low.contains("sent") || low.contains("receiv")) {
				String msg = "[Cortisol debug] " + (r != null ? "MATCH " + r.name() + " " + r.amount() : "NO MATCH")
						+ " | " + ChatParse.normalize(text);
				LOG.info(msg);
				Minecraft.getInstance().execute(() -> {
					if (Minecraft.getInstance().player != null) {
						Minecraft.getInstance().player.displayClientMessage(Component.literal(msg), false);
					}
				});
			}
		}
		if (r == null) return;
		Minecraft.getInstance().execute(() -> handlePayment(r.name(), r.amount()));
	}

	private static int test(FabricClientCommandSource src, String rawAmount, String name) {
		long amount = Amounts.parse(rawAmount);
		if (amount <= 0) {
			src.sendFeedback(Component.literal("Cortisol: couldn't read amount '" + rawAmount + "' (try 150k, 12m, 2b)"));
			return 0;
		}
		handlePayment(name, amount);
		return 1;
	}

	public static void handlePayment(String name, long amount) {
		state.add(name, amount);
		String shown = "$" + Amounts.format(amount);

		// END STREAM: one huge payment, or the running total crossing the line
		if (!state.endTriggered && (amount >= config.endStreamTotal || state.grandTotal >= config.endStreamTotal)) {
			state.endTriggered = true;
			Fx.end();
			Overlay.push(Overlay.Kind.END, "END STREAM", "$" + Amounts.format(state.grandTotal) + " HIT. YOU HAVE TO END STREAM.");
			return;
		}

		Fx.payment(name, amount);

		if (amount >= config.insaneMin) {
			Overlay.push(Overlay.Kind.INSANE, name + " PAID " + shown, "ABSOLUTELY INSANE");
		} else if (amount >= config.crazyMin) {
			Overlay.push(Overlay.Kind.CRAZY, name + " PAID " + shown, "that's crazy");
		}

		if (amount >= config.tokenMinPayment && config.tokenOdds > 0
				&& ThreadLocalRandom.current().nextInt(config.tokenOdds) == 0) {
			givePirateToken(name);
		}
	}

	public static void givePirateToken(String name) {
		state.totals.putIfAbsent(name, 0L);
		state.pin(name, config.pinMinutes * 60_000L);
		Fx.token(name);
		Overlay.push(Overlay.Kind.TOKEN,"PIRATE TOKEN PULLED", name + " takes #1 for " + config.pinMinutes + " minutes");
		Overlay.showBoard(config.leaderboardShowSeconds);
	}
}
